<?php
    session_start();
    $name="wangxinyu";
    $_SESSION['name']=$name;
    echo "成功保存session";
  ?>