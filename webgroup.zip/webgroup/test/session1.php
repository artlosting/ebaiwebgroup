<?php
    session_start();
    $sessionpath=session_save_path();        //获取当前session的保存路径
    echo $_SESSION['name'];
 ?>