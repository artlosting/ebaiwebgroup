<?php
    require_once 'MemberModel.class.php';
    //修改用用户
    $schoolId=$_POST['schoolId'];
    $username=$_POST['username'];
    $password=$_POST['password'];
    $phone=$_POST['phone'];
    $email=$_POST['email'];
    $userdate=$_POST['userdate'];
    //$userfileId=$_POST['userfileId'];
    $do=$_GET['do'];
    //调用model来处理逻辑
    if($do=='reg'){
    	 $memberModel=new MemberModel();
	    $b=$memberModel->addMember($schoolId, $username, $password, $phone, $email, $userdate);
	    if($b==1){
			header("Location: ok.php?do=1");
	        exit();
	    }else if($b==0||$b==2){
	        header("Location:reg.php?do=0");
			echo "注册失败，请重新注册";
	        exit();
    	}
    }else if($do=='amend'){
    	//amend就是update
    	/*  $memberModel=new MemberModel();
		  $b=$memberModel->updateMember(){*/
		  	
		  }
    
   
?>







