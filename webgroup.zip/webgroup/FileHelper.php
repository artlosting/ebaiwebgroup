<?php
    //打开文件
    class FileHelper{
        public $root;
        public $filename;
        public $fp;    
        
        //$file_sub_dir变量格式： 项目总文件夹/子文件夹
      //读取文件，并把文件内容一次换行
       public function openFile($file_sub_dir,$filename){
           $root=$_SERVER["DOCUMENT_ROOT"];
           $file_path="$root/$file_sub_dir/$filename";
           //判断文件是否存在
           if(!file_exists("$file_path")){
               echo "文件不存在";
           }else {
               $fp=fopen($file_path,'rb');
               $content_line=fgets($fp);
               //开始读取文件
               $content="";
               while (!feof($fp)){
                   $content_line=fgets($fp);
                   $content.=$content_line."<br/>";
               }
               //echo gettype("$content");//判断文件的类型是string，下面就是用explode（）函数拆分的问题了
               $content_array=explode('@',$content);
               //遍历数组
               for($i=0; $i<count($content_array); $i++){
                   echo $content_array[$i]."<br/>";

               }
               fclose($fp);
           }
         }
  }
 ?>
 
 
 
 
 
 
 
 
 
 
    