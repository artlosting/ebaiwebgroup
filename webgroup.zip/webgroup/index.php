<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="Author" content="河南理工大学e佰web开发组">
<meta name="Keywords" content="河南理工大学e佰计算机协会、河南理工大学e佰web开发组、e佰web组，e佰web前端，e佰web后端">
<meta name="Description" content="河南理工大学e佰计算机协会、河南理工大学e佰web开发组、web组分为前后端、e佰web组，e佰web前端，e佰web后端">
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>e佰web组首页</title>
<link rel="stylesheet" type="text/css" href="css/all.css"/>
<link href="index.css" rel="stylesheet" type="text/css" media="screen" />
<link rel="stylesheet" type="text/css" href="css/ebaiLogo.css"/>
<script type="text/javascript" src="./js/datetime.js"></script>
<script language="javascript">
function Time(){
	document.getElementById("localtime").innerText=new Date().toLocaleString();
  }
setInterval("Time()",1000);
</script>
<script language="javascript">
		document.getElementsByTagName('ul')[0].getElementsByTagName('li')[1].style.width = '200px';
</script>
</head>
<body>
	
<?php 
   session_start();
   if(empty($_SESSION['password'])){
       header("Location:memberLogin.php?error=3");
   }
   $schoolId=$_SESSION['schoolId'];
   /* echo $schoolId;
   exit(); */
?>
<div class="music">
	
		<embed width="0px" height="0px" src="#" hidden="true"></embed>
<!--
	http://play.baidu.com/?__m=mboxCtrl.playSong&__a=1362159&__o=song/s||playBtn&fr=-1||www.baidu.com#
    	作者：hpuwxy@foxmail.com
    	时间：2016-03-19
    	描述：
   		<object data="song/bgmusic.mp3" type="application/x-mplayer2" width="0" height="0"> 
		<param name="src" value="song/bgmusic.mp3"> 
		<param name="autostart" value="1"> 
		<param name="playcount" value="infinite"> 
	</object> 
    -->
	
</div>
<!--整体的外框，相当于body-->
<div id="wrapper">
	<div id="page">
		<div id="page-bgtop">
			<div id="page-bgbtm">
				<div id="content">
					
					<!--时间-->
						<!--这个要通过js实现时间自动刷新的功能-->
					<div class="top2">
						<div class="datetime">
							<span id="localtime" class="time"></span>
						</div>
						<!--格言-->
						<div class="motto">
							<span class="myMotto">平庸，只因只有想梦，却没有梦想。</span>
						</div>
					</div>
					<div class="amend">
						<span class="amend">
							<a href="admin/amendMemberInfor.php?done=memberUpdate" class="amendInfor">修改个人信息</a>
							<a href="?act=logout">安全退出</a>
							<?php 
							  
							     if(@$_GET['act']=='logout'){
							         session_start();
							         session_destroy();
							         header("Location:index.html");
							     }
							?>
						</span>
					</div>
					<div style="clear: both;"></div>
					<!--content分为四个post部分-->
					<div class="post">
						<h2 class="title">1.共勉，共进！！！</h2>
						<div style="clear: both;">&nbsp;</div>
						<div class="entry">
							<p>
							如果你想超越自己；<br/><br/>
							如果你想实现梦想；<br/><br/>
							这里也许是你最佳的驿站；<br/><br/>
							这里，你可以什么都没有;<br/><br/>
							这里，你可以从零开始;<br/><br/>
							只需要你有激情，只需要你肯努力。<br/><br/>
							希望有着共同爱好的我们，挥洒出我们的青春。<br/><br/>因为爱着，所以执着；因为相信，所以坚信。期待此时的我们明天会更好。
							</p>
						</div>
					</div>
					<div class="post">
						<h2 class="title">2.深情建议：</h2>
						<div style="clear: both;">&nbsp;</div>
						<div class="entry">
							<p>（1）.积极锻炼，身体是革命的本钱，这句话可不是开玩笑的，因为身体的原因而不能继续下去，大有人在;<br/><br/>
							（2）.你们需协调好爱好与学业之间的关系，否则难以持续下去;<br/></br> （3）.一入此站，说明了你么想学点东西说明的，若真想学点对自己未来有帮助的东西的话，游戏，电影，小说，聊天...这些你可能都要舍弃了，因为你时间并不比别人多，当然偶尔也可以，松弛有度最好；<br/><br/> （5）.说一下对于一些学习的经验，每天学习的内容不要太多，但要每天坚持，大哲学家伏尔泰曾经说过，要在这个世界上获得成功，就必须坚持到底：至死都不能放手”。如果你想看到明天的太阳，那么请默默地坚持下去吧！</p>
						</div>
					</div>
					<div class="post">
						<h2 class="title">3.学、思、辩、德：</h2>
						<div style="clear: both;">&nbsp;</div>
						
						<div class="entry">
							<p>&nbsp;&nbsp;&nbsp;&nbsp;   活到老，学到老。你是绝对不可能把所有的知识都学完的，社会发展日新月异，而技术也是不断涌现，不断消亡的。也许，你今天所学的东西，明天就已经淘汰了，而被一个更好的技术或方法所替代，这一点在我们IT领域尤为重要，切记切记！！！所以说，学只是你人生当中必备的技能，而更应该在学的过程中，通过切身的感悟，而达到思考，一个人如果有了思考，那么学习呢，也就自然不是什么难事了，在思考的过程中，其实你已经慢慢的有了自己的思想，自己的理解，但你的理解可能会与真理有出入。那么你会难免的与其他人发生冲突，思想难免会发生碰撞，在这一阶段，你需要明辨是非，知己也能知彼，然后融合思想，升华思想，成为自己的思想。好了，如果你能完成这三个阶段，我想你已经成为了一个技术大牛甚至某一个领域的精英或专家了。但你里大师的距离还差了一个“德”字，最后一点就是要学会感恩，感恩父母，感恩老师，感恩朋友，感谢身边的每一位曾经帮助过你的人。做事情要有责任心，一个没有责任心的人，即使技术再娴熟，也很难有所作为！！！				
							</p>
						</div>
					</div>
					<div class="post">
						<h2 class="title">4.网站建设的目标：</h2>
						<div style="clear: both;">&nbsp;</div>
						<div class="entry">
							<p>（1）为了能让你来到大学不迷茫，来到e佰计算机协会不后悔，来到web组不虚度。所以建立了这个网站，希望通过这个小小的平台，让你找到自己的小窝，让你找到归属感。<br/><br/>
							（2）通过我们共同的努力，建设一个更美好的未来。这个网站计划将成为web组未来每届人才汇聚的平台，依靠每一届成员的努力，来不断完善我们的web组。<br/><br/>
							（3）因为年轻。所以无极限,加油!!!
							</p>
							<p></p>
						</div>
					</div>
					<div style="clear: both;">&nbsp;</div>
				</div>
				<!-- end #content -->
				<!--工具栏---->
				<div id="sidebar">
					<div id="logo">
						<h1><a href="index.php"><font face="华文行楷">e佰web组</font></a></h1>
					</div>
					<div id="menu">
						<ul>
							<li class="current_page_item"><a href="index.php">web深情建议：</a></li>
							<li><a href="webfront.php">web前端介绍：</a></li>
							<li><a href="webafter.php">web后端介绍：</a></li>
							<li><a href="webfrontline.php">web前端学习：</a></li>
							<li><a href="webafterline.php">web后端学习：</a></li>
							<li><a href="webresource.php">web总体资料：</a></li>
							<li><a href="allplans.php">web整体计划：</a></li>
						</ul>
					</div>
					<div class="calendar">
						<?php 
							include("./tool/calendar.html");
						?>
					</div>
					<div class="ebaijishulianmeng">
						<span class="ebaijishulianmeng_title">特别关注：</span>
						<div class="ebaijishulianmeng_links">
							<div class="qq_links">
								<ul>
									<li style="type-list-style:none;">
										<h2><a href="#">Q Q群:</a></h2>	
									</li>
									<li>
										<h2><a href="http://jq.qq.com/?_wv=1027&k=ZNOcLF ">web-e佰技术联盟</a></h2>	
									</li>
								</ul>
							</div>
							<div class="weixin_links">
								<ul>
									<li style="type-list-style:none;">
										<h2><a href="#">微信号:</a></h2>	
									</li>
									<li>
										<h2><a href="#">e佰web前端</a></h2>	
									</li>
									<li>
										<h2><a href="#">e佰web后端</a></h2>
									</li>
								</ul>
							</div>
						</div>
					</div>
					
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
				</div>
			</div>
	<!-- end #page-bgtop-->
		</div>
	<!--end #page-->
	</div>
<!--end #wrapper-->
</div>
<div id="footer">
	<p>Copyright (c) 2016 web.com. All rights reserved. Design by 河南理工大学e佰计算机协会web组.</p>
</div>
<!-- end #footer -->
</body>
</html>
