<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="Generator" content="EditPlus®">
  <meta name="hpuwxy" content="注册页面后指定要登录的地方">
  <meta name="Keywords" content="web组成员注册，登录">
  <meta name="Description" content="web组注册，登录">
  <title>成功</title>
  <script language="javascript">
	function change(){
		$("time").style.color="red";
		$("time").innerText=$("time").innerText-1;
		if($("time").innerText==0){
			clearInterval(timer);
			open("memberLogin.php","_self");
		}

	}
	var timer=setInterval("change()",1000);
	function $(id){
		return document.getElementById(id);
	}
  </script>
 </head>
 <body>
 	<div class="allservice">
 		<?php
 			$do=$_GET['do'];
			 if(!empty($_GET['do'])){
			 	if($do==1){
			 		echo "<h1>注册成功</h1>";
			 	}else if($do==0){
			 		echo "<h1>注册失败</h1>";
			 	}else if($do==3){
			 		echo "<h1>你好！暂未开通成员注册功能！</h1>";
			 	}
			 }		
 		?>
  		<span id="time"><font color="red">5</font></span>秒后返回到登录界面！<br/>
  	</div>
  
 </body>
</html>








