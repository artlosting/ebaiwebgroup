<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="Author" content="河南理工大学e佰web开发组">
<meta name="Keywords" content="河南理工大学e佰计算机协会、河南理工大学e佰web开发组、e佰web组，e佰web前端，e佰web后端">
<meta name="Description" content="河南理工大学e佰计算机协会、河南理工大学e佰web开发组、web组分为前后端、e佰web组，e佰web前端，e佰web后端">
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>e佰web组后端介绍</title>
<link rel="stylesheet" type="text/css" href="css/all.css"/>
<link href="./css/webafterIntroduce.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/ebaiLogo.css"/>
<script type="text/javascript" src="./js/datetime.js"></script>

<script language="javascript">
function Time(){
	document.getElementById("localtime").innerText=new Date().toLocaleString();
  }
setInterval("Time()",1000);
</script>
</head>
<body>
	<?php 
   session_start();
   if(empty($_SESSION['password'])){
       header("Location:memberLogin.php?error=3");
   }
?>
<div class="music">

		<embed width="0px" height="0px" src="#" hidden="true"></embed>
	<!--
		http://play.baidu.com/?__m=mboxCtrl.playSong&__a=1362159&__o=song/s||playBtn&fr=-1||www.baidu.com#
    	作者：hpuwxy@foxmail.com
    	时间：2016-03-19
    	描述：
   		<object data="song/bgmusic.mp3" type="application/x-mplayer2" width="0" height="0"> 
		<param name="src" value="song/bgmusic.mp3"> 
		<param name="autostart" value="1"> 
		<param name="playcount" value="infinite"> 
	</object> 
    -->
	
</div>
<!--整体的外框，相当于body-->
<div id="wrapper">
	<div id="page">
		
		<div id="page-bgtop">
			
			<div id="page-bgbtm">
				
				<div id="content">
					<div class="top2">
							<!--时间-->
							<!--这个要通过js实现时间自动刷新的功能-->
						<div class="datetime">
							<span id="localtime" class="time"></span>
						</div>
						<!--格言-->
						<div class="motto">
							<span class="myMotto">平庸，只因只有想梦，却没有梦想。</span>
						</div>
					</div>
					<div class="amend">
						<span class="amend">
							<a href="admin/amendMemberInfor.php?done=memberUpdate" class="amendInfor">修改个人信息</a>
							<a href="?act=logout">安全退出</a>
							<?php 
							  
							     if(@$_GET['act']=='logout'){
							         session_start();
							         session_destroy();
							         header("Location:index.html");
							     }
							?>
						</span>
					</div>
					<div style="clear: both;"></div>
					<!--content分为四个post部分-->
					<div class="post">
						<h2 class="title">1.背景：</h2>
						<div style="clear: both;">&nbsp;</div>
						<div class="entry">
						<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;PHP最初是1994年Rasmus Lerdorf创建的，刚刚开始只是一个简单的用Perl语言编写的程序，用来统计他自己网站的访问者。后来又用C语言重新编写，包括可以访问数据库。在 1995年以Personal HomePageTools (PHP Tools) 开始对外发表第一个版本，Lerdorf写了一些介绍此程序的文档，并且发布了PHP1.0。在这早期的版本中，提供了访客留言本、访客计数器等简单的功能。以后越来越多的网站使用了PHP，并且强烈要求增加一些特性，比如循环语句和数组变量等等，在新的成员加入开发行列之后，在1995年中，PHP2.0发布了。第二版定名为PHP/FI(FormInterpreter)。PHP/FI加入了对MySQL的支持，从此建立了PHP在动态网页开发上的地位。到了1996年底，有15000个网站使用 PHP/FI；时间到了1997年中，使用PHP/FI的网站数字超过五万个。而

在1997年中，开始了第三版的开发计划，开发小组加入了 Zeev Suraski 及 Andi Gutmans，而第三版就定名为PHP3。2000年，

PHP4.0又问世了，其中增加了许多新的特性。
在2000年5月22日，以Zend Engine 1.0为基础的PHP 4正式释出，2004年7月13日则释出了PHP 5，PHP 5则使用了第二代的Zend 

Engine[5]。PHP包含了许多新特色，像是强化的面向对象功能、引PDO（PHPData Objects，一个存取数据库的延伸函数库）、

以及许多效能上的增强。目前PHP 4已经不会继续更新，以鼓励用户转移到PHP 5。
2008年PHP 5成为了PHP唯一的有在开发的PHP版本。将来的PHP 5.3将会加入Late static binding和一些其他的功能强化。PHP 

6 的开发也正在进行中，主要的改进有移除register_globals、magic quotes 和 Safe mode的功能等。
						</p>
						</div>
					</div>
					<div class="post">
						<h2 class="title">2.技术支持：</h2>
						<div style="clear: both;">&nbsp;</div>
						<div class="entry">
						
							<div class="all-technique">
								<h3>后端基础:</h3>
									HTML<br/>
									CSS<br/>
									PHP语法<br/>
							</div>
							<div class="all-technique">
								<h3>后端进阶:</h3>  
									http协议<br/>  
									cookie与session<br/>
									错误处理<br/>
									MySQL数据库<br/>
									smarty模板引擎<br/>
									页面静态化<br/>
									数据库优化<br/>
									memcache<br/>
							</div>
							<div class="all-technique">
							<h3>后端框架:</h3>
								thinkPHP<br/>
								YII<br/>
								Zend Framework<br/>
		</div>
							<div class="all-technique">
							<h3>后端项目:</h3>
							ecshop项目<br/>
							dedecms项目<br/>
							wordpress项目<br/>	
							cms项目<br/>
						</div>
						</div>
					</div>
					<div class="post">
						<h2 class="title">3.PHP特性:</h2>
						<div style="clear: both;">&nbsp;</div>
						<div class="entry">
							<p>
							1. PHP 独特的语法混合了 C、Java、Perl 以及 PHP 自创新的语法。<br/><br/>
							2. PHP可以比CGI或者Perl更快速的执行动态网页——动态页面方面，与其他的编程语言相比，PHP是将程序嵌入到HTML文档中去执行，执行效率比完全生成htmL标记的CGI要高许多；PHP具有非常强大的功能，所有的CGI的功能PHP都能实现。<br/><br/>
							3. PHP支持几乎所有流行的数据库以及操作系统。<br/><br/>
							4. 最重要的是PHP可以用C、C++进行程序的扩展！<br/><br/>
							</p>
						</div>
					</div>		
					<div style="clear: both;">&nbsp;</div>
				</div>
				<!-- end #content -->
				<!--工具栏---->
					<div id="sidebar">
					<div id="logo">
						<h1><a href="index.php"><font face="华文行楷">e佰web组</font></a></h1>
					</div>
					<div id="menu">
						<ul>
							<li><a href="index.php">web深情建议：</a></li>
							<li><a href="webfront.php">web前端介绍：</a></li>
							<li class="current_page_item"><a href="webafter.php">web后端介绍：</a></li>
							<li><a href="webfrontline.php">web前端学习：</a></li>
							<li><a href="webafterline.php">web后端学习：</a></li>
							<li><a href="webresource.php">web总体资料：</a></li>
							<li><a href="allplans.php">web整体计划：</a></li>
						</ul>
					</div>
					<div class="calendar">
						<?php 
						include("./tool/calendar.html");
						?>
					</div>
					<div class="ebaijishulianmeng">
						<span class="ebaijishulianmeng_title">特别关注：</span>
						<div class="ebaijishulianmeng_links">
							<div class="qq_links">
								<ul>
									<li style="type-list-style:none;">
										<h2><a href="#">QQ群</a></h2>	
									</li>
									<li>
										<h2><a href="http://jq.qq.com/?_wv=1027&k=ZNOcLF ">web-e佰技术联盟</a></h2>	
									</li>
								</ul>
							</div>
							<div class="weixin_links">
								<ul>
									<li style="type-list-style:none;">
										<h2><a href="#">微信号</a></h2>	
									</li>
									<li>
										<h2><a href="#">e佰web前端</a></h2>	
									</li>
									<li>
										<h2><a href="#">e佰web后端</a></h2>
									</li>
								</ul>
							</div>
						</div>
					</div>
					
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
				</div>
			</div>
	<!-- end #page-bgtop-->
		</div>
		</div>
	<!--end #page-->
	</div>
<!--end #wrapper-->
</div>
<div id="footer">
	<p>Copyright (c) 2016 web.com. All rights reserved. Design by 河南理工大学e佰计算机协会web组.</p>
</div>
<!-- end #footer -->
</body>
</html>
