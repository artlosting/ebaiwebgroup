<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>成员信息</title>
<link href="css/inforMember.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
	//确认删除该用户
	function confirmDel(id){
		//这个函数返回bool
		return window.confirm("真的删除 "+id+"学号成员吗？");
	}
</script>
</head>
<body>
<div class="allservice">
        <div class="getLasttime">
			<span>上次登录时间是:
						 <?php 
    						 require_once 'commonFuns.php';
    						 userIsValid();
    						//显示上次登陆
    						getLastTime();
						?> 
			</span>
        </div>
	<h1>成员信息</h1>
	<div class="showMember">
		<?php 
            //连接数据库
            require_once 'MemberModel.class.php';
            header("content-type:text/html;charset=utf-8");
            //连接数据库
            $conn=mysql_connect("localhost","root","root") or die("连接出错".mysql_error());
            mysql_query("set names utf8");
            //选择数据库
            mysql_select_db("members");
            $sql="select * from members";
            $res=mysql_query($sql,$conn);
            echo "<table class='inforMember'>";
            echo "<tr><td>学号</td><td>用户名</td><td>密码</td><td>手机号</td><td>电子邮件</td><td>出生日期</td><td>修改成员</td><td>删除成员</td></tr>";
            
            while($row=mysql_fetch_assoc($res)){
                echo "<tr><td>{$row['schoolId']}</td><td>{$row['username']}</td><td>{$row['password']}</td><td>{$row['phone']}</td><td>{$row['email']}</td><td>{$row['userdate']}</td><td><a href='amendMemberInfor.php?done=adminUpdate&schoolId={$row['schoolId']}'>修改成员</a></td><td><a onclick='return confirmDel({$row['schoolId']})' href='deleteMember.php?do=delete&schoolId={$row['schoolId']}'>删除成员</a></td></tr>";
            }
            echo "</table>";
        ?>
</div>
<a href="mainCurd.php">返回主页面</a>
</div>
</body>
</html>
