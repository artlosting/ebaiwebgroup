<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>管理员登录修改添加状态</title>
	<style type="text/css">
         .container{
         	margin-top:40px;
	        text-align:center;
         	font-size:30px;
         }
    </style>
	<script language="javascript">
		function change(){
			$("time").style.color="red";
			$("time").innerText=$("time").innerText-1;
			if($("time").innerText==0){
				clearInterval(timer);
				open("mainCurd.php","_self");
			}
		}
		var timer=setInterval("change()",1000);
		function $(id){
			return document.getElementById(id);
		}
  </script>
</head>
	<body>
		<div class="container">
			<?php
			$do=$_GET['do'];

			switch ($do){
			    case 'loginOk':
			        echo "<h1>登陆成功！</h1>";
			        echo "<span id='time' color='red'>5</span>秒后跳转到管理页面！<br/>";
			        break;
			    case 'addOk':
			        echo "<h1>添加成员成功！</h1>";
			        echo "<span id='time' color='red'>5</span>秒后跳转到管理页面！<br/>";
			        break;
			    case 'addError':
			        echo "<h1>添加成员失败！</h1>";
			        echo "<span id='time' color='red'>5</span>秒后跳转到管理页面！<br/>";
			        break;
			    case 'updateOk':
			        echo "<h1>修改信息成功！</h1>";
			        echo "<span id='time' color='red'>5</span>秒后跳转到主页面！<br/>";
			        break;
			    case 'updateError':
			        echo "<h1>修改信息成功！</h1>";
			        echo "<span id='time' color='red'>5</span>秒后跳转到主页面！<br/>";
			        break;
		        case 'updateNone':
		            echo "<h1>没有修改数据，请重新修改！</h1>";
		            echo "<span id='time' color='red'>5</span>秒后跳转到主页面！<br/>";
		            break;
	            case 'deleteOk':
	                echo "<h1>删除管理员成功！</h1>";
	                echo "<span id='time' color='red'>5</span>秒后跳转到主页面！<br/>";
	                break;
                case 'deleteError':
                    echo "<h1>删除管理员失败！</h1>";
                    echo "<span id='time' color='red'>5</span>秒后跳转到主页面！<br/>";
                    break;
		}
		?>
		</div>
		
	</body>
</html>
