<?php
	
	//接收用户要删除的用户的id
	//获取用户传输的do  是 
	//通过MemberModel的一个方法.
	require_once 'AdminModel.class.php';
	$adminModel=new AdminModel();
	//判断用户是希望执行什么操作
	
	if(!empty($_GET['do'])){
			//获取do值
			$do=$_GET['do'];
			//希望执行删除
			if($do=='delete'){
				//说明用户希望删除某个用户
				$adminId=$_GET['adminId'];
				$b=$adminModel->deleteAdminById($adminId);
				//删除.这里不要连接数据.
				if($b==1){
					//成功!
					header("Location:adminOk.php?do=deleteOk");
					//这里我们建议增加exit函数，提高效率
					exit();
				}else{
					//失败!
					header("Location:adminOK.php?do=deleteError");
					//这里我们建议增加exit函数，提高效率
					exit();
				}
				
			}else if($do=='add'){
				
				//获取提交信息
				$adminId=$_POST['adminId'];
				$username=$_POST['username'];
				$password=$_POST['password'];
				$phone=$_POST['phone'];				
				$email=$_POST['email'];
				if($adminModel->addAdmin($adminId,$username,$password,$phone,$email)==1){
					//成功!
					header("Location: adminOk.php?do=addOk");
					//这里我们建议增加exit函数，提高效率
					exit();
				}else{
					//失败!
					header("Location: adminOk.php?do=addError");
					//这里我们建议增加exit函数，提高效率
					exit();
				}
			}else if($do=='update'){
				//获取提交信息
				$schoolId=$_POST['adminId'];
				$username=$_POST['username'];
				$password=$_POST['password'];
				$phone=$_POST['phone'];				
				$email=$_POST['email'];
				//update这里可能是用户没有修改就直接提交，
				$b=$adminModel->updateAdmin($adminId,$username,$password,$phone,$email);
			     if($b==1){
					    header("Location:adminOk.php?do=updateOk");
					    exit();
				}else if($b==0){
					    header("Location:adminOk.php?do=updateError");
					    exit();
					
				}else if($b==2){
				         header("Location:adminOk.php?do=updateNone");
				        //到管理员页面
				       //echo "<script type='text/javascript'>window.alert('没有数据修改');location.href='amendMemberInfor.php;</script>";
				        exit();
				}
			}
        }
?>