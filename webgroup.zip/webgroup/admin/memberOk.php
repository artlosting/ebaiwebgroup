<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>成员登录或修改状态</title>
	<style type="text/css">
         .container{
         	margin-top:40px;
	        text-align:center;
         	font-size:30px;
         }
    </style>
	<script language="javascript">
		function change(){
			$("time").style.color="red";
			$("time").innerText=$("time").innerText-1;
			if($("time").innerText==0){
				clearInterval(timer);
				open("../index.php","_self");
			}
		}
		var timer=setInterval("change()",1000);
		function $(id){
			return document.getElementById(id);
		}
  </script>
</head>
	<body>
	<div class="container">
		<?php
			$do=$_GET['do'];
			if($do=='login'){
				echo "<h1>登陆成功！</h1>";
				echo "<span id='time' color='red'>10</span>秒后跳转到主页面！<br/>";
			}else if($do=='none'){
			   	echo "<h1>没有修改数据！</h1>";
				echo "<span id='time' color='red'>10</span>秒后跳转到主页面！<br/>";
			}else if($do=='updateOk'){
			    echo "<h1>修改信息成功</h1>";
			    echo "<span id='time' color='red'>5</span>秒后跳转到主页面！<br/>";
			}else if($do=='updateError'){
			    echo "<h1>修改信息失败，请重新修改！</h1>";
			    echo "<span id='time' color='red'>10</span>秒后跳转到主页面！<br/>";	
			}else if($do=='updateNone'){
			    echo "<h1>信息没有修改，请重新修改！</h1>";
			    echo "<span id='time' color='red'>10</span>秒后跳转到主页面！<br/>";
			}
		?>
	</div>
		
	</body>
</html>












