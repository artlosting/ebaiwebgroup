<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>增删改查</title>
<style type="text/css">
    .container{
         	margin-top:100px;
	        text-align:center;
         	font-size:40px;
	        type-style:none;
         }
    .container .status{
	       type-decoration:none;
        }
</style>
</head>
<body>
<div class="container">
	<?php
    header("content-type:text/html;charset=utf-8");
	//接收用户要删除的用户的id
	//获取用户传输的do  是 
	//通过MemberModel的一个方法.
	require_once 'MemberModel.class.php';
	$memberModel=new MemberModel();
	//判断用户是增删改查的哪一种
	
	if(!empty($_GET['do'])){
			//获取do值
			$do=$_GET['do'];
			$done=$_GET['done'];
/*         //数据都正确的渠道了
			var_dump($done);

			echo "<br/>";
	 		echo $do;
			exit;  */
	
			//希望执行删除
			if($do=="delete"){
				//说明用户希望删除某个用户
				$id=$_GET['id'];
				//删除.这里不要连接数据.
				if($memberModel->deleteById($id)==1){
					//成功!
					header("Location: ok.html");
					//这里我们建议增加exit函数，提高效率
					exit();
				}else{
					//失败!
					header("Location: error.html");
					//这里我们建议增加exit函数，提高效率
					exit();
				}
				
			}else if($do=='add'){
				
				//获取提交信息
				$schoolId=$_POST['schoolId'];
				$username=$_POST['username'];
				$password=$_POST['password'];
				$phone=$_POST['phone'];				
				$email=$_POST['email'];
				$userdate=$_POST['userdate'];
				if($memberModel->addMember($schoolId,$username,$password,$phone,$email,$userdate)==1){
					//成功!
					header("Location: ok.php?do=addOk");
					//这里我们建议增加exit函数，提高效率
					exit();
				}else{
					//失败!
					header("Location: error.html");
					//这里我们建议增加exit函数，提高效率
					exit();
				}
			}else if($do=='update'){
				//获取提交信息
				$schoolId=$_POST['schoolId'];
				$username=$_POST['username'];
				$password=$_POST['password'];
				$phone=$_POST['phone'];				
				$email=$_POST['email'];
				$userdate=$_POST['userdate'];
			    $done=$_GET['done'];//获取来自index.php或manageMember.php的文件
			    
				$res=$memberModel->updateMember($schoolId,$username,$password,$phone,$email,$userdate);
				if($res==1){
			
					//成功!判断是否成员自己修改还是管理员修改
					if($done=='memberUpdate'){
					    
					    echo "<a class='status' href='memberOk.php?do=updateOk'>点击查看修改状态！</a>";
					    // header("Location：memberOk.php?do=updateOk");
					    //这里我们建议增加exit函数，提高效率
					    exit();
					}else if($done=='adminUpdate'){
					    //到管理员页面
					    header("Location:adminOk.php?do=updateOk");
					    exit();
					}
					
				}else if($res==0){
				//判断是否成员自己修改还是管理员修改
					if($done=='memberUpdate'){
					   echo "<a href='memberOk.php?do=updateError'>点击查看修改状态！</a>";
					   //  header("Location：memberOk.php?do=updateError");
					    //这里我们建议增加exit函数，提高效率
					    exit();
					}else if($done=='adminUpdate'){
					    //到管理员页面
					    header("Location:adminOk.php?do=updateError");
					    exit();
					}
				}else if($res==2){
				   
				    //update这里可能是用户没有修改就直接提交，
				    //成功!判断是否成员自己修改还是管理员修改
				    if($done=='memberUpdate'){
				        echo "<a href='memberOk.php?do=updateNone'>点击查看修改状态！</a>";
				        //echo "<script type='text/javascript'>window.alert('没有数据修改');location.href='amendMemberInfor.php;</script>";
				        //这里我们建议增加exit函数，提高效率
				        exit();
				    }else if($done=='adminUpdate'){
				         header("Location:adminOk.php?do=updateNone");
				        //到管理员页面
				       //echo "<script type='text/javascript'>window.alert('没有数据修改');location.href='amendMemberInfor.php;</script>";
				        exit();
				    }
				}
			}
	}
?>
	
</div>

</body>
</html>