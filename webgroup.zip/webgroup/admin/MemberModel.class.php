<?php

	require_once 'SqlHelper.class.php';

	class MemberModel{
	
		function showMemberByPage2($fenyePage){
			
			$sqls[0]="select count(*) from emp";
			$sqls[1]="select * from emp limit "
			.($fenyePage->pageNow-1)*$fenyePage->pageSize.",".$fenyePage->pageSize;
			$sqlHelper=new SqlHelper();
			//因为分页不只是 emp表分页，还有其它
			$sqlHelper->execute_dql_page($sqls,$fenyePage);
			
			//关闭!!!!
			$sqlHelper->my_close();
			
		}
		
		//根据id删除一个用户

		//添加用户
		function addMember($schoolId,$username,$password,$phone,$email,$userdate){
			$password=md5($password);
			$sql="insert into members (schoolId,username,password,phone,email,userdate) value('$schoolId','$username','$password','$phone','$email','$userdate');";
			$sqlHelper=new SqlHelper();
			$result=$sqlHelper->execute_dml($sql);
			$sqlHelper->my_close();
			return $result;
			
		}
		//提供一个通过
		function seaEmp($keyword,$type,$fenyePage){
			//组织 sql
			//type是模糊查询
			if ($type=="1") {
				$sql[0]="select count(*) from emp where name like '%$keyword%'";
				$sql[1]="select * from emp where name like '%$keyword%' limit "
				.($fenyePage->pageNow-1)*$fenyePage->pageSize.",".$fenyePage->pageSize;
			
			
			}else if($type=="2"){
				//$sql="select * from emp where name='$keyword'";
			}
			
			$sqlHelper=new SqlHelper();
			//$arr=$sqlHelper->execute_dql2($sql);
			$sqlHelper->execute_dql_page($sql,$fenyePage);
			$sqlHelper->my_close();
		}
		
		//更新用户
		function updateMember($schoolId,$username,$password,$phone,$email,$userdate){
			
			//组织$sql  password  passwd 
			//对数据进行加密
			$password=md5("$password");
		/* 	echo $password;
			exit(); */
			$sql="update members set schoolId='$schoolId',username='$username',password='$password',phone='$phone',email='$email',userdate='$username' where schoolId='$schoolId'";
			$sqlHelper=new SqlHelper();
			$result=$sqlHelper->execute_dml($sql);
			$sqlHelper->my_close();
			return $result;//0,1,2
		}
		
		function getMemberByschoolId($schoolId){
			
			$sql="select * from members where schoolId='$schoolId'";
			$sqlHelper=new SqlHelper();
			$arr=$sqlHelper->execute_dql2($sql);
			$sqlHelper->my_close();
			return $arr;
		}
		
		}
?>