<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<div>
    <?php
        //连接数据库
        $conn=mysql_connect("localhost","root","root");
        if(!$conn){
            die("连接不成功".mysql_error());
        }
        mysql_select_db("members");
        $schoolId=$_GET['schoolId'];
        $sql="delete from members where schoolId=$schoolId";
        $res=mysql_query($sql,$conn);
        if(!$res){
            // return 0;//表示删除不成功能
            header("Location:manageMember.php");
            echo "<script lanuage='javascript'>window.alert('没有连接到数据库');</script>";
          
        }else{
            if(mysql_affected_rows($conn)>0){
                //return 1;//删除成功
                header("Location:manageMember.php");
            echo "<script lanuage='javascript'>window.alert('删除成功');</script>";

            }else{
                //return 2;//行数没有受到影响
                header("Location:manageMember.php");
                echo "<script lanuage='javascript'>window.alert('删除不成功');</script>";
        
            }
        }
    ?>
</div>
</body>
</html>

