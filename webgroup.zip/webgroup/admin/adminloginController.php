<?php
//接收成员的的id号和密码
   //1.接收用户的id
   $adminId=$_POST['adminId'];
    if(!empty($adminId)){
        $adminId=$_POST['adminId'];
    }else{
    	header("Location:../adminLogin.php?error=1");
		exit();
    }
    //2.接收用户的密码
    $password=$_POST['password'];
    if(!empty($password)){
        $password=$_POST['password'];
    }else{
		header("Location:../adminLogin.php?error=2");
		exit();
      }
	  if($adminId=="" && $password==""){
		 header("Location:../adminLogin.php?error=1");
		  exit();
	}
        //创建AdminModel对象
     require_once 'AdminModel.class.php';
        $adminModel=new AdminModel();
        //调用核对密码的的方法,并返回结果集
        $res=$adminModel->checkAdmin($adminId, $password);
        //根据res的不同而做出相应的处理
        if($res=="ok"){
            //这里我们把管理员的id保存起来
            if(isset($_POST['keepid'])){
                //如果管理员选中的话就保存到cookie里
                setcookie("adminId",$adminId,time()+3600);
            }else{
                 //看是否以前登录过保存了没，如果保存，现在不想保存了，就把他删了，如果这是第一次登录
                if(isset($_COOKIE['adminId'])){
                        setcookie("adminId","",time()-100);
                  }
            }
            //保存管理员的信息到session
            session_start();
            $_SESSION['adminId']=$adminId;
            header("Location:adminOk.php?do=loginOk");
     
        }else if($res=="5"){
             header("Location:../adminLogin.php?error=5");
        }else if($res=="1"){
              header("Location:../adminLogin.php?error=1");
               }
 ?>
        
        
        
        
        
        
        
        
        
    
        
        
        