<?php
error_reporting(E_ALL ^ E_DEPRECATED);
//提供一个操作数据库的工具类
    class SqlHelper{
        public $dbName="members";
        public $host="localhost";
        public $userName="root";
        public $password="root";
        public $conn;
        
        public function __construct(){
                $this->conn=mysql_connect($this->host,$this->userName,$this->password);
            if(!$this->conn){
                die("连接不成功".mysql_error());
            }
            mysql_query("set names utf8");
            mysql_select_db($this->dbName,$this->conn) or die("选择数据库出错");
        }
        //提供一查询函数 dql(select) dml(update,delete,insert)
        
        public function execute_dql($sql){
            $res=mysql_query($sql,$this->conn) or die("查询失败".mysql_error());
            return $res;
        }
        
        public function execute_dql2($sql){
            $res=mysql_query($sql,$this->conn) or die("查询失败".mysql_error());
            //定义一个数组，然后把查询到的数据保存到数组中去
            $arr=array();
            while ($row=mysql_fetch_assoc($res)) {
                //每一行都是一个数组的元素
                $arr[]=$row;
            }
            mysql_free_result($res);
            return $arr;
        }
        public function execute_dml($sql){
            $b=mysql_query($sql,$this->conn) or die("语句出错".mysql_error());
            if(!$b){
                return 0;
            }else{
                if(mysql_affected_rows($this->conn)>0){
                    return 1;
                }else{
                    return 2;
                }
            }
        }
        //执行sql 批量执行
        public function execute_dml3($sqls){
            for($i=0; $i<count($sqls); $i++){
                $this->execute_dql($sqls[$i]);
            }
        }
        //关闭连接
        public function my_close(){
            if(!empty($this->conn)){
                mysql_close($this->conn);
            }
        }
             
    
    }
    
    ?>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    