<?php
    //验证用户是否是合法的用户
        function userIsValid(){
            session_start();
            if(empty($_SESSION['adminId'])){
                header("Location:../adminLogin.php?error=3");
            }
        }
        //从cookie中获取上次保存的时间
    function getLastTime(){
        //设置中国时间
        date_default_timezone_get("PRC");
        if(!isset($_COOKIE['lasttime'])){
            //获取当前时间，然后保存
            setcookie("lasttime",date('Y-m-d H:i:s'),time()+3600);
            echo "欢迎你首次登录";
        }else{
            echo $_COOKIE['lasttime'];
            setcookie("lasttime",date('Y-m-d H:i:s'),time()+3600);
        }
    }
    //得到上次登录的schoolId,然后通过schoolId从数据库中取出username
    function getCookieKey($key){
        if(isset($_COOKIE[$key])){
            echo $_COOKIE[$key];
        }else{
            echo "";
        }
    }
    
    //判断是管理员还是普通成员
    function judgePerson($done){
        //成功!判断是否成员自己修改还是管理员修改
        if($done=='memberUpdate'){
            header("Location：memberOk.php?do=update");
            //这里我们建议增加exit函数，提高效率
            exit();
        }else if($done=='adminUpdate'){
            //到管理员页面
            header("Location:adminOk.php?do=update");
            exit();
        }
    }
   
?>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    