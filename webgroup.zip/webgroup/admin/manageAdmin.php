<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>管理员信息</title>
<link href="css/inforMember.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="allservice">
        <div class="getLasttime">
			<span>上次登录时间是:
						 <?php 
    						 require_once 'commonFuns.php';
    						 userIsValid();
    						//显示上次登陆
    						getLastTime();
						?> 
			</span>
        </div>
	<h1>管理员信息</h1>
	<div class="showMember">
		<?php 
            //连接数据库
            require_once 'AdminModel.class.php';
            header("content-type:text/html;charset=utf-8");
            //连接数据库
            $conn=mysql_connect("localhost","root","root") or die("连接出错".mysql_error());
            mysql_query("set names utf8");
            //选择数据库
            mysql_select_db("members");
            $sql="select * from admin";
            $res=mysql_query($sql,$conn);
            echo "<table class='inforMember'>";
            echo "<tr><td>学号</td><td>用户名</td><td>密码</td><td>手机号</td><td>电子邮件</td><td>修改成员</td><td>删除成员</td></tr>";
            
            while($row=mysql_fetch_assoc($res)){
                echo "<tr><td>{$row['adminId']}</td><td>{$row['username']}</td><td>{$row['password']}</td><td>{$row['phone']}</td><td>{$row['email']}</td><td><a href='amendAdminInfor.php?adminId={$row['adminId']}'>修改成员</a></td><td><a href='addAdminController.php?do=delete&adminId={$row['adminId']}'>删除成员</a></td></tr>";
            }
            echo "</table>";
        ?>
</div>
<a href="mainCurd.php">返回主页面</a>
</div>
</body>
</html>
