<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>web组成员修改个人信息</title>
<link href="../css/reg.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="../css/login.css"/>
<script type="text/javascript" language="javascript">
	
		function checkinfo(){
			document.getElementById('span1').innerText="";
			document.getElementById('span2').innerText="";
			document.getElementById('span3').innerText="";
			document.getElementById('span4').innerText="";
			document.getElementById('span5').innerText="";
			document.getElementById('span6').innerText="";
			//获取表单的学号
			 if(document.forms[0].schoolId.value.length!=12){
    			document.getElementById('span1').innerText="你的学号长度应为12位";
    			alert("你的学号应为12位");
				return false;
			}
			//获取表单的姓名
		 	if(document.forms[0].username.value.length<1||document.forms[0].username.value.length>20){
				document.getElementById('span2').innerText="你的姓名应该为你的真实姓名！";
				return false;
			} 
			//获取密码并判断
			if(document.forms[0].password.value.length<=3){
				document.getElementById('span3').innerText="密码不能为空且不能少于3位！";
				return false;
			}
			//验证密码
			if(document.forms[0].password.value!=document.forms[0].password1.value){
				document.getElementById('span4').innerText="两次密码不一致，请重新输入！";
				return false;
			}
			//验证手机号
			if(doucment.forms[0].phone.value.length!=11){
				documment.getElementById('span5').innerText="你的电话号码应为11位数字！";
				return false;
			}else{
				var str=document.forms[0].phone.value.length;
				var pattern=/^1[3,5,8]{1}[0-9]{1}[0-9]{8}|0[0-9]{2,3}-[0-9]{7,8}(-[0-9]{1,4})?/;
				if(pattern.test(str)){
				
				}else{
					documment.getElementById('span5').innerText="你的电话号码格式不正确！";
					return false;
					}
				}
			//验证邮箱
			if(document.forms[0].email.value!=""){
				var str=doucment.forms[0].email.value;
				var email_pattern=/([a-z0-9_\-\.]+)@(([a-z0-9]+[_\-]?)\.)+[a-z]{2,3}/i;
				//判断
				if(email_pattern.test(str)){
					document.getElementById('span6').innerText="你的邮箱格式不正确，请重新输入！";
					return false;
					}
			}else{
    				document.getElementById('span6').innerText="你的邮箱格式不正确，请重新输入！";
    				return false;
				}
		}
	</script>
</head>

<body>
	<?php  
		require_once 'MemberModel.class.php';
		$done=$_GET['done'];//获取来自index.php成员修改的数据memberUpdate,和来自manageMember.php管理员修改的数据adminUpdate
		//判断是用户操作还是管理员操作
		/* echo $done;
		exit; */
		if($done=='memberUpdate'){
		    session_start();
		    $schoolId=$_SESSION['schoolId'];
		    $memberModel=new MemberModel();
		    $arr=$memberModel->getMemberByschoolId($schoolId);
		
		}else if($done='adminUpdate'){
		    
		    $schoolId=$_GET['schoolId'];
		    $memberModel=new MemberModel();
		    $arr=$memberModel->getMemberByschoolId($schoolId);
		}
	   /* 	?do=update&done=<?php echo $done?> */
	?>
  	<div class="container">
   		<form  enctype="multipart/form-data" name="myform" action="addMemberController.php?do=update&done=<?php echo $done?>" method="POST">
  			<p><a href="#">修改个人信息：</a></p>	
      			<table cellspacing="0">	
      				<tr><td><label>你的学号:</label></td><td><input id="schoolId" name="schoolId" type="text" value="<?php echo $arr[0]['schoolId'];?>"/></td><td><span id="span1"></span></td></tr>
      				<tr><td><label>你的姓名:</label></td><td><input id="username" name="username" type="text" value="<?php echo $arr[0]['username'];?>"/></td><td><span id="span2"></span></td></tr>
      				<tr><td><label>你的密码:</label></td><td><input id="password" name="password" type="password" value="<?php echo $arr[0]['password']?>"/></td><td><span id="span3"></span></td></tr>
      				<tr><td><label>你的电话:</label></td><td><input id="phone" type="tel" name="phone" data-ideal="phone" value="<?php echo $arr[0]['phone'];?>"/></td><td><span id="span5"></span></td></tr>
          			<tr><td><label>你的邮箱:</label></td><td><input id="email" name="email" data-ideal="required email" type="email" value="<?php echo $arr[0]['email'];?>"/></td><td><span id="span6"></span></td></tr>
          			<tr><td><label>出生日期:</label></td><td><input name="userdate" class="datepicker" data-ideal="date" type="text" placeholder="年/月/日" value="<?php echo $arr[0]['userdate'];?>"/></td><td><span id="span7"></span></td></tr>
    				<tr>
        				<td colspan="1"><input type="submit" value="点击修改"  onclick="return checkinfo()" /></td>
        			 	<td><input type="reset" value="重新填写"/></td>
        			 	<td><a href="../index.php">返回到主页</a></td>
    			 	</tr>
      			</table>
     
  		</form>
  
  	</div>
</body>
</html>





