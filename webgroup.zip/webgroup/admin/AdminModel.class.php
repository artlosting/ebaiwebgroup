<?php
    require_once 'SqlHelper.class.php';
    class AdminModel{
        //提供验证用户是否合法的方法
        function checkAdmin($adminId,$password){
            $sqlHelper=new SqlHelper();
            
            //1.获得$adminid密码进行比较
            $sql="select password from admin where adminId={$adminId}";
            $res=$sqlHelper->execute_dql($sql);
            //取出密码
            if($row=mysql_fetch_row($res)){
                if(md5("$password")==$row[0]){
                    return "ok";
                }else{
                    return "5";//密码错误
                }
            }else{
                return "2";//行没有影响
            }
            //释放资源
            mysql_free_result($res);
            //关闭连接
            $sqlHelper->my_close();
            
        }
        //添加管理员
        function addAdmin($adminId,$username,$password,$phone,$email){
            $password=md5($password);
            $sql="insert into admin(adminId,username,password,phone,email) value('$adminId','$username','$password','$phone','$email');";
            $sqlHelper=new SqlHelper();
            $b=$sqlHelper->execute_dml($sql);
            $sqlHelper->my_close();
            return $b;
             
        }
        //更新管理员
        function updateAdmin($adminId,$username,$password,$phone,$email){
            	
            //组织$sql  password  passwd
            //对数据进行加密
            $password=md5("$password");
            /* 	echo $password;
             exit(); */
            $sql="update admin set adminId='$adminId',username='$username',password='$password',phone='$phone',email='$email' where adminId='$adminId'";
            $sqlHelper=new SqlHelper();
            $b=$sqlHelper->execute_dml($sql);
            $sqlHelper->my_close();
            return $b;//0,1,2
        }
        //删除管理员
        function deleteAdminById($adminId){
            $sql="delete from admin where adminId=$adminId";
            $sqlHelper=new SqlHelper();
            $b=$sqlHelper->execute_dml($sql);
            return $b;
        }
        //获取管理员信息
        function getAdminById($adminId){
            $sql="select * from admin where $adminId=$adminId";
            $sqlHelper=new SqlHelper();
            $res=$sqlHelper->execute_dql2($sql);
            return $res;
        }
    }
        
 ?>   
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 