<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link href="css/addMember.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" language="JavaScript">
	function memberClick(){
		form1.action="addmemberController.php?do=add";
		form1.submit();
}
	function adminClick(){
		form2.action="addadminController.php?do=add"；
		form2.submit();
}
</script>
</head>
<body>
<div class="addservice">
	<div class="getLasttime">
		<span>上次登录时间是:
			 <?php 
				 require_once 'commonFuns.php';
				 userIsValid();
				//显示上次登陆
				getLastTime();
			?> 
		</span>
	</div>
	<h1>添加成员或管理员</h1>
	<div id="con">
		<ul id="tags">
			  <li><a onClick="selectTag('tagContent0',this)" href="javascript:void(0)">添加成员</a></li>
			  <li class="selectTag"><a onClick="selectTag('tagContent1',this)" href="javascript:void(0)">添加管理员</a></li>
		</ul>
		
		<div id="tagContent">
			<div class="tagContent" id="tagContent0">
				<div class="addmember">
			    	<form action="addMemberController.php?do=add" method="post" name="form1">
				        <table cellspacing="0">
				        	<caption>成员信息:</caption>
				            <!-- 建议大家这里给text取名的时候，就和数据库的字段保持一致 -->
				            <tr><td>学号：</td><td><input type="text" name="schoolId" /></td></tr>
				            <tr><td>用户名：</td><td><input type="text" name="username" /></td></tr>
				            <tr><td>密码：</td><td><input type="password" name="password" /></td></tr>
				            <tr><td>手机号：</td><td><input type="text" name="phone" /></td></tr>
				            <tr><td>邮箱：</td><td><input type="text" name="email" /></td></tr>
				            <tr><td>出生日期：</td><td><input type="text" name="userdate" /></td></tr>
				            <tr><td><input type="submit" name="member" value="添加成员" /></td><td><input type="reset" value="重新填写" /></td></tr>
				        </table>
			    	</form>
				</div>
			</div>
			<div class="tagContent" id="tagContent1">
				<div class="addAdmin">
			    	<form action="addAdminController.php?do=add" method="post" name="form2">
				        <table cellspacing="0">
				        	<caption>管理员信息:</caption>
				            <!-- 建议大家这里给text取名的时候，就和数据库的字段保持一致 -->
				            <tr><td>adminId：</td><td><input type="text" name="adminId" /></td></tr>
				            <tr><td>用户名：</td><td><input type="text" name="username" /></td></tr>
				            <tr><td>密码：</td><td><input type="password" name="password" /></td></tr>
				            <tr><td>手机：</td><td><input type="text" name="phone" /></td></tr>
				            <tr><td>邮箱：</td><td><input type="text" name="email" /></td></tr>
				            <tr><td><input type="submit" name="admin" value="添加管理员" /></td><td><input type="reset" value="重新填写" /></td></tr>
				        </table>
			    	</form>
				</div>
			</div>
		</div>
	</div>
	<div>
		<a href="mainCurd.php">返回到管理系统主页</a>
	</div>
</div>

<script type=text/javascript>
	function selectTag(showContent,selfObj){
		// 给标签先清空然后附上指定的class选择器
		var tag = document.getElementById("tags").getElementsByTagName("li");
		var taglength = tag.length;
		for(var i=0; i<taglength; i++){
			tag[i].className = "";
		}
		//给所有的li加上selectTag 标签
		selfObj.parentNode.className = "selectTag";
		// 标签内容
		for(i=0; j=document.getElementById("tagContent"+i); i++){
				j.style.display = "none";
		}
		document.getElementById(showContent).style.display = "block";
	}
</script>
</body>
</html>

