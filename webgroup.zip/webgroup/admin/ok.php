<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title></title>
	<script language="javascript">
		function change(){
			
			$("time").innerText=$("time").innerText-1;
			if($("time").innerText==0){
				clearInterval(timer);
				open("mainCurd.php","_self");
			}
		}
		var timer=setInterval("change()",1000);
		function $(id){
			return document.getElementById(id);
		}
  </script>
</head>
	<body>
		<?php
			$do=$_GET['do'];
			
			if($do=='login'){
				echo "<h1>登陆成功！</h1>";
				echo "<span id='time'>5</span>秒后跳转到管理页面！<br/>";
			}else if($do=='update'){
				echo "<h1>修改信息成功！</h1>";
				echo "<span id='time'>5</span>秒后跳转到管理页面！<br/>";
			}else if($do=='addOk'){
			    echo "<h1>添加成员成功！</h1>";
			    echo "<span id='time'>5</span>秒后跳转到管理页面！<br/>";
			}else if($do=='addError'){
			    echo "<h1>添加成员成功！</h1>";
			    echo "<span id='time'>5</span>秒后跳转到管理页面！<br/>";	
			}
		?>
	</body>
</html>












