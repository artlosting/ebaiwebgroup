<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>欢迎登陆后台管理系统</title>
<link rel="stylesheet" href="css/mainCurd.css" type="text/css" />
<script language="javascript">
function Time(){
	document.getElementById("localtime").innerText=new Date().toLocaleString();
  }
setInterval("Time()",1000);
</script>
</head>
<body>
	<div class="allservice">
		<div class="top">
		<!--格言-->
    		<div class="motto">
    			<span class="myMotto">平庸，只因只有想梦，却没有梦想。</span>
    		</div>
			<!--这个要通过js实现时间自动刷新的功能-->
			<div class="datetime">
				<span id="localtime" class="time"></span>
			</div>
    		<div style="clear: both;"></div>
    		<div class="getLasttime">
    			<span>上次登录时间是:
					 <?php 
						 require_once 'commonFuns.php';
						 userIsValid();
						//显示上次登陆
						getLastTime();
					?> 
    			</span>
    		</div>
			<div class="amend">
				<span class="amend">
					<a href="?act=logout">安全退出</a>
						<?php 
						     if(@$_GET['act']=='logout'){
						         session_start();
						         session_destroy();
						         header("Location:../index.html");
						     }
						?>
				</span>
			</div>
		</div>
		<div style="clear: both;"></div>
		<h1>欢迎登录后台管理系统</h1>
		<div class="membercurd">
		<!-- 这是一个对普通成员的操作 -->
			<h2>成员</h2>
    		<ul>
    			<li><a href="addAll.php">增加成员</a></li>
    			<li><a href="manageMember.php">查看成员信息</a></li>
    		</ul>
    	</div>
    	<!-- 这是一个对管理员的操作 -->
    	<div class="admincurd">
			<h2>管理员</h2>
    		<ul>
    			<li><a href="addAll.php">增加管理员</a></li>
    			<li><a href="manageAdmin.php">查看管理员信息</a></li>
    		</ul>
    	</div>
    	<!-- 进入到前台 -->
    	<div class="frontservice">
			<h2>前台</h2>
    		<ul>
    			<li><a href="../memberLogin.php">进入到前台</a></li>
    		</ul>
    	</div>
	</div>
</body>
</html>


