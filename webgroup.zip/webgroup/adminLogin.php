<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>web组管理员登录</title>
<link href="./css/adminLogin.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php 
    require_once './admin/commonFuns.php';
?>
<div class="poetry"> 
	<h3 align="center" style="font-family:华文行楷;">面朝大海，春暖花开</h3>
	 <p style="font-family:隶书;">
	 <br/>
	从明天起，做一个幸福的人 <br/>
	喂马、劈柴，周游世界<br/>
	从明天起，关心粮食和蔬菜<br/>
	我有一所房子，面朝大海，春暖花开<br/>
	从明天起，和每一个亲人通信<br/>
	告诉他们我的幸福<br/>
	那幸福的闪电告诉我的<br/>
	我将告诉每一个人<br/>
	给每一条河每一座山取一个温暖的名字<br/>
	陌生人，我也为你祝福<br/>
	愿你有一个灿烂的前程<br/>
	愿你有情人终成眷属<br/>
	愿你在尘世获得幸福<br/>
	我只愿面朝大海，春暖花开<br/>
	</p>
</div> 
<div class="pic"></div>
<div class="music">
	
	<embed width="0px" height="0px" src="song/bgmusic.mp3" hidden="true"></embed>
	<!--
    	作者：hpuwxy@foxmail.com
    	时间：2016-03-19
    	描述：
    	<object data="song/bgmusic.mp3" type="application/x-mplayer2" width="0" height="0"> 
		<param name="src" value="song/bgmusic.mp3"> 
		<param name="autostart" value="1"> 
		<param name="playcount" value="infinite"> 
	</object> 
    -->
	
</div>
<div style="text-align:center;clear:both;"></div>
<!---->
<div class="hintError">
	<?php 
	//看看返回错误信息
	//$errno=@$_GET['errno']; //null "" ->false
	
        if(!empty($_GET['error'])){
        		$errno=$_GET['error'];
        		if($errno==1){
        			echo "<font color='red'>你的id号和密码不能为空！</font>";
        		}else if($errno==2){
        			echo "<font color='red'>你的密码不能为空！</font>";
        		}else if($errno==3){
        		    echo "<font color='red'>警告！非法登录！请用正确的id号和密码登录！</font>";
        		}else if($errno==4){
        		    echo "<font color='red'>你输入的id号有误！请用正确的学号和密码登录！</font>";
        		}else if($errno==5){
        		    echo "<font color='red'>你输入的密码有误！请输入正确的密码！</font>";
        		}
        		
        	}

?>
</div>
<div class="login-form">
	<form action="admin/adminloginController.php" method="POST">
		<table cellspacing="0">
			<tr><td colspan="2"><h1 style="font-family: 华文行楷;">欢迎登陆web组</h1></td></tr>
			<tr><td>你的id号:</td><td><input type="text" name="adminId" value='<?php getCookieKey('adminid')?>'/></td></tr>
			<tr><td>你的密码:</td><td><input type="password" name="password"/></td></tr>
			<tr><td>是否要保存你的id号</td><td><font size="5px">不保存</font><input type="radio" name="keepid"><font size="5px">一次</font><input type="radio" name="keepid"><font size="5px">一周</font><input type="radio" name="keepid"></td></tr>
			<tr><td><input type="submit" value="登录"/></td><td><input type="reset" value="重新填写"/></td></tr>
		</table>
	</form>
</div>
</body>
</html>







