<?php
  header("Content-Type: text/html;charset=utf-8"); 
    require_once 'SqlHelper.class.php';
    //该类是一个业务处理类，主要完成对admin表的操作
    class MemberModel{
        //核对成员
        public function checkMember($schoolId,$password){
            $sql="select schoolId,password,username from members where schoolId='$schoolId';";
            //创建一个sqlhelper对象
            $sqlHelper=new SqlHelper();
            $res=$sqlHelper->execute_dql($sql);
            if ($row=mysql_fetch_assoc($res)){
                //比对密码
                if(md5("$password")==$row['password']){
                    //将密码和用户名保存到session中
                    session_start();
                    $_SESSION['password']=$password;
                
                    $_SESSION['schoolId']=$schoolId;
                    return $row['username'];
                }
            }
            mysql_free_result($res);
            //连接
            $sqlHelper->close_connect();
          
            return "";
        }
       /*  $schoolId=$_POST['schoolId'];
        $username=$_POST['username'];
        $password=$_POST['password'];
        $phone=$_POST['phone'];
        $email=$_POST['email'];
        $userdate=$_POST['userdate'];
        $userfileId=$_POST['userfileId']; */
        
        //执行添加用户
        public function addMember($schoolId, $username,$password,$phone,$email, $userdate){
            $sql="insert into members(schoolId,username,password,phone,email,userdate) values('$schoolId', '$username',md5('$password'),'$phone','$email', '$userdate');";
            $sqlHelper=new SqlHelper();
            
            return $sqlHelper->execute_dml($sql);
            
        }
        
    }
?>












