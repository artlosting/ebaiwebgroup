function openFile(){
	var ForReading=1; 
	//创建对象
	var fso=new ActiveXObject("Scripting.FileSystemObject"); 
	//打开文件
	var f=fso.OpenTextFile("i:\\WWW/webGroup/webafterline.txt",ForReading); 
	var arr=f.ReadAll().split("\r\n"); 
	//遍历每一个行
	var s="";
	for(var i=0; i<arr.length; i++){	
	s+=arr[i]+"<br/>";
	}
	document.getElementById("webafterline").innerHTML=s;
}
openFile();
