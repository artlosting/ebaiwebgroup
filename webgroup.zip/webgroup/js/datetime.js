/*function dateTime(){
			today = new Date();
			var x, year;
			var x = new Array("星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六");
			var MSIE = navigator.userAgent.indexOf("MSIE");
			if (MSIE != -1)
				year = (today.getFullYear());
			else
				year = (today.getYear() + 1900);
			var tdate = year + "年" + (today.getMonth() + 1) + "月" + today.getDate() + "日" + " " + x[today.getDay()];
			document.getElementById("localtime").innerText=tdate;
}
dateTime();
*/	
function Time(){
	document.getElementById("localtime").innerText=new Date().toLocaleString();
  }
setInterval("Time()",1000);
					
