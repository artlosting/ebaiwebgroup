<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>web组注册</title>
<link href="./css/reg.css" rel="stylesheet" type="text/css" />
 <script language="javascript">
	function change(){
		$("time").innerText=$("time").innerText-1;
		if($("time").innerText==0){
			clearInterval(timer);
			open("index.html","_self");
		}

	}
	var timer=setInterval("change()",1000);
	function $(id){
		return document.getElementById(id);
	}
  </script>
</head>
<body>
<h1>注册成功！</h1>
  <span id="time"><font color="red">5</font></span>秒后自动登录！<br/>
  	<div class="reg-form">
  	
  		<form action="addMemberController.php" method="POST">
  			<h1>WeB组成员注册：</h1>	
  				<legend></legend>  
      			<table cellspacing="0">	
      				<tr><td><label>学号:</label></td><td><input id="schoolId" name="schoolId" type="text"/></td><td><span id="span1"></span></td></tr>
      				<tr><td><label>姓名:</label></td><td><input id="username" name="username" type="text"/></td><td><span id="span2"></span></td></tr>
      				<tr><td><label>密码:</label></td><td><input id="password" name="password" type="password"/></td><td><span id="span3"></span></td></tr>
      				<tr><td><label>确认密码:</label></td><td><input id="password" name="password1" type="password"/></td><td><span id="span4"></span></td></tr>
      				<tr><td><label>电话:</label></td><td><input type="tel" name="phone" data-ideal="phone"/></td><td><span id="span5"></span></td></tr>
          			<tr><td><label>邮箱:</label></td><td><input id="email" name="email" data-ideal="required email" type="email"/></td><td><span id="span6"></span></td></tr>
          			<tr><td><label>出生日期:</label></td><td><input name="userdate" class="datepicker" data-ideal="date" type="text" placeholder="年/月/日"/></td><td><span id="span7"></span></td></tr>
          			<tr><td><label>上传头像:</label></td><td><input id="file" name="userfileId" multiple type="file"/></td><td></td></tr>
    				<tr>
        				<td colspan="1"><input type="submit" value="点击注册"  onclick="return checkinfo()" /></td>
        			 	<td><input type="reset" value="重新填写"/></td>
    			 	</tr>
      			</table>
     
  		</form>
  
  	</div>
</body>
</html>





