<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>web组成员登录</title>
<link href="./css/memberLogin.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php 
    require_once './admin/commonFuns.php';
?>
<div class="poetry"> 
	<h3 align="center" style="font-family:华文行楷;">面朝大海，春暖花开</h3>
	 <p style="font-family:隶书;">
	 <br/>
	从明天起，做一个幸福的人 <br/>
	喂马、劈柴，周游世界<br/>
	从明天起，关心粮食和蔬菜<br/>
	我有一所房子，面朝大海，春暖花开<br/>
	从明天起，和每一个亲人通信<br/>
	告诉他们我的幸福<br/>
	那幸福的闪电告诉我的<br/>
	我将告诉每一个人<br/>
	给每一条河每一座山取一个温暖的名字<br/>
	陌生人，我也为你祝福<br/>
	愿你有一个灿烂的前程<br/>
	愿你有情人终成眷属<br/>
	愿你在尘世获得幸福<br/>
	我只愿面朝大海，春暖花开<br/>
	</p>
</div> 
<!---这是一个图片，自动旋转功能--->
<div class="pic"></div>

<!--
	作者：hpuwxy@foxmail.com
	时间：2016-03-19
	描述：这是一个外挂百度的音乐
-->
<div class="music">

		<embed width="0px" height="0px" src="http://play.baidu.com/?__m=mboxCtrl.playSong&__a=1362159&__o=song/s||playBtn&fr=-1||www.baidu.com#" hidden="true"></embed>
	<!--
    	作者：hpuwxy@foxmail.com
    	时间：2016-03-19
    	描述：
   		<object data="song/bgmusic.mp3" type="application/x-mplayer2" width="0" height="0"> 
		<param name="src" value="song/bgmusic.mp3"> 
		<param name="autostart" value="1"> 
		<param name="playcount" value="infinite"> 
	</object> 
    -->
	
</div>
<div style="text-align:center;clear:both;"></div>
<!--
	作者：hpuwxy@foxmail.com
	时间：2016-03-16
	描述：
-->
<div class="hintError">
	<?php 
	//看看返回错误信息
	//$errno=@$_GET['errno']; //null "" ->false
	
	if(!empty($_GET['error'])){
		$errno=$_GET['error'];
		if($errno==1){
			echo "<font color='red'>你的学号不能为空或学号输入有误</font>";
		}else if($errno==2){
			echo "<font color='red'>你的密码不能为空或密码不正确</font>";
		}else if($errno==3){
		    echo "<font color='red'>警告！非法登录！请用正确的学号和密码登录！！</font>";
		}else if($errno==4){
		    echo "<font color='red'>输入的学号或密码有误！！请用正确的学号和密码登录！！</font>";
		}else if($errno==5){
		    echo "<font color='red'>验证码输入不正确！请点击图片重新输入正确的验证码</font>";
		}else if($errno==6){
		    echo "<font color='red'>验证码输入不能为空！</font>";
		}
	}

?>
</div>
<div class="login-form">
	<form action="loginController.php" method="POST">
		<table cellspacing="0">
			<tr><td colspan="2"><h1 style="font-family: 华文行楷;">欢迎登陆web组</h1></td></tr>
			<tr><td>你的学号:</td><td><input type="text" name="schoolId"/></td></tr>
			<tr><td>你的密码:</td><td><input type="password" name="password"/></td></tr>
			<!-- 
						<tr><td colspan='2'>验证码是:<input type="text" name="checkcode"/><img src="common/checkCode.php" onclick="this.src='checkCode.php"/></td></tr>
			
			 -->
			<tr><td><input type="submit" value="登录"/></td><td><input type="reset" value="重新填写"/></td></tr>
			<tr><td colspan="2" font-size="15px">亲，首次登录需先注册，才能登录哦。点击<a href="./reg.php">注册</a></td></tr>
		</table>
	</form>
</div>
</body>
</html>







