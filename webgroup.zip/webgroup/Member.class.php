<?php
    class Member{
        private $schoolId;
        private $username;
        private $password;
        private $phone;
        private $email;
        private $userdate;
        private $userfileId;
  /**
     * @return the $schoolId
     */
    public function getSchoolId()
    {
        return $this->schoolId;
    }

  /**
     * @return the $username
     */
    public function getUsername()
    {
        return $this->username;
    }

  /**
     * @return the $password
     */
    public function getPassword()
    {
        return $this->password;
    }

  /**
     * @return the $phone
     */
    public function getPhone()
    {
        return $this->phone;
    }

  /**
     * @return the $email
     */
    public function getEmail()
    {
        return $this->email;
    }

  /**
     * @return the $userdate
     */
    public function getUserdate()
    {
        return $this->userdate;
    }

  /**
     * @return the $userfileId
     */
    public function getUserfileId()
    {
        return $this->userfileId;
    }

  /**
     * @param field_type $schoolId
     */
    public function setSchoolId($schoolId)
    {
        $this->schoolId = $schoolId;
    }

  /**
     * @param field_type $username
     */
    public function setUsername($username)
    {
        $this->username = $username;
    }

  /**
     * @param field_type $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }

  /**
     * @param field_type $phone
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;
    }

  /**
     * @param field_type $email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

  /**
     * @param field_type $userdate
     */
    public function setUserdate($userdate)
    {
        $this->userdate = $userdate;
    }

  /**
     * @param field_type $userfileId
     */
    public function setUserfileId($userfileId)
    {
        $this->userfileId = $userfileId;
    }

    

    }
?>