<?php
 //接收成员的的id号和密码
   //1.接收用户的id
   $schoolId=$_POST['schoolId'];
    if(!empty($schoolId)){
        $schoolId=$_POST['schoolId'];
       
    }else{
    	header("Location:memberLogin.php?error=1");
		exit();
    }
    //2.接收用户的密码
    $password=$_POST['password'];
    if(!empty($password)){
        $password=$_POST['password'];
    }else{
		header("Location:memberLogin.php?error=2");
		exit();
      }
	  if($schoolId=="" && $password==""){
		 header("Location:memberLogin.php?error=1");
		  exit();
	}
	//3.验证验证码
	/* $checkcode=$_POST['checkcode'];
	if(!empty($schoolId)){
	    session_start();
    	if($checkCode!=$_SESSION['myCheckCode']){
    		header("Location:memberlogin.php?error=5");
    		exit();
	    }
	}else{
	    header("Location:memberLogin.php?error=6");
	    exit();
	} */
    require_once 'MemberModel.class.php';
    //接收用户的数据
    //判断用户
    //实例化成员memberModel方法
    $memberModel=new MemberModel();
    $username=$memberModel->checkMember($schoolId, $password);
  /*  echo $username;
   exit(); */
    if($username!=""){          
        header("Location:index.php?username=$username");
        exit();
    }else{
        header("Location:memberLogin.php?error=4");
        exit();
    }
    
?>




