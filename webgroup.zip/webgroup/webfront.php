<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="Author" content="河南理工大学e佰web开发组">
<meta name="Keywords" content="河南理工大学e佰计算机协会、河南理工大学e佰web开发组、e佰web组，e佰web前端，e佰web后端">
<meta name="Description" content="河南理工大学e佰计算机协会、河南理工大学e佰web开发组、web组分为前后端、e佰web组，e佰web前端，e佰web后端">
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>e佰web组前端介绍</title>
<link rel="stylesheet" type="text/css" href="css/all.css"/>
<link href="./css/webfrontIntroduce.css" rel="stylesheet" type="text/css" media="screen" />
<link rel="stylesheet" type="text/css" href="css/ebaiLogo.css"/>
<script type="text/javascript" src="./js/datetime.js"></script>
<script language="javascript">
function Time(){
	document.getElementById("localtime").innerText=new Date().toLocaleString();
  }
setInterval("Time()",1000);
</script>
</head>
<body>
	<?php 
   session_start();
   if(empty($_SESSION['password'])){
       header("Location:memberLogin.php?error=3");
   }
?>
<div class="music">

		<embed width="0px" height="0px" src="#" hidden="true"></embed>
	<!--http://play.baidu.com/?__m=mboxCtrl.playSong&__a=1362159&__o=song/s||playBtn&fr=-1||www.baidu.com#
    	作者：hpuwxy@foxmail.com
    	时间：2016-03-19
    	描述：
   		<object data="song/bgmusic.mp3" type="application/x-mplayer2" width="0" height="0"> 
		<param name="src" value="song/bgmusic.mp3"> 
		<param name="autostart" value="1"> 
		<param name="playcount" value="infinite"> 
	</object> 
    -->
	
</div>
<!--整体的外框，相当于body-->
<div id="wrapper">
	<div id="page">
		
		<div id="page-bgtop">
			
			<div id="page-bgbtm">
				
				<div id="content">
					<div class="top2">
						<!--时间-->
						<!--这个要通过js实现时间自动刷新的功能-->
						<div class="datetime">
							<span id="localtime" class="time"></span>
						</div>
						<!--格言-->
						<div class="motto">
							<span class="myMotto">平庸，只因只有想梦，却没有梦想。</span>
						</div>
					</div>
					<div class="amend">
						<span class="amend">
							<a href="admin/amendMemberInfor.php?done=memberUpdate" class="amendInfor">修改个人信息</a>
							<a href="?act=logout">安全退出</a>
							<?php 
							  
							     if(@$_GET['act']=='logout'){
							         session_start();
							         session_destroy();
							         header("Location:index.html");
							     }
							?>
						</span>
					</div>
					<div style="clear: both;"></div>
					<!--content分为四个post部分-->
					<div class="post">
						<h2 class="title">1.背景：</h2>
						<div style="clear: both;">&nbsp;</div>
						<div class="entry">
						<p>
    2005年以后，互联网进入Web 2.0时代，各种类似桌面软件的Web应用大量涌现，网站的前端由此发生了翻天覆地的变化。网页不再只是承载单一的文字和图片，各种丰富媒体让网页的内容更加生动，网页上软件化的交互形式为用户提供了更好的使用体验，这些都是基于前端技术实现的。
</p>
						</div>
					</div>
					<div class="post">
						<h2 class="title">2.技术支持：</h2>
						<div style="clear: both;">&nbsp;</div>
						<div class="entry">
							<div class="all-technique">
							<h3>前端基础:</h3>
    HTML<br/>
    CSS<br/>
    JavaScript<br/>
    HTML5<br/>
    CSS3<br/>
    技术前瞻</div>
							<div class="all-technique">
							<h3>前端进阶:</h3>
    Typescript<br/>
    前端安全<br/>
    项目实战</div>
							<div class="all-technique">
							<h3>前端框架:</h3>
    jQuery<br/>
    jQuery UI<br/>
    jQuery Mobile<br/>
    AngularJS<br/>
    ReactJS<br/>
    Bootstrap<br/>
    React Native<br/>
    Backbone<br/>
    Three.js<br/>
    MooTools<br/>
    Compass</div>
							<div class="all-technique">
							<h3>HTML5游戏:</h3>
    Canvas<br/>
    SVG<br/>
    WebGL<br/>
    Cocos2d-js<br/>
    CreateJS<br/>
    Flash<br/>
    Unreal<br/>
    Egret<br/>
    Phaser</div>
							
						</div>
					</div>
					<div class="post">
						<h2 class="title">3.如何才能做得更好呢？</h2>
						<div style="clear: both;">&nbsp;</div>
						
						<div class="entry">
				<p>第一，必须掌握基本的Web前端开发技术，其中包括：CSS、HTML、DOM、BOM、Ajax、JavaScript等，在掌握这些技术的同时，还要清楚地了解它们在不同浏览器上的兼容情况、渲染原理和存在的Bug。<br/><br/>
				第二，在一名合格的前端工程师的知识结构中，网站性能优化、SEO和服务器端的基础知识也是必须掌握的。<br/><br/>
				第三，必须学会运用各种工具进行辅助开发。
				第四，除了要掌握技术层面的知识，还要掌握理论层面的知识，包括代码的可维护性、组件的易用性、分层语义模板和浏览器分级支持，等等。<br/><br/>&nbsp;&nbsp;&nbsp;&nbsp;   可见，看似简单的网页制作，如果要做得更好、更专业，真的是不简单。这就是前端开发的特点，也是让很多人困惑的原因。
				如此繁杂的知识体系让新手学习起来无从下手，对于老手来说，也时常不知道下一步该学什么。
				代码质量是前端开发中应该重点考虑的问题之一。例如，实现一个网站界面可能会有无数种方案，但有些方案的维护成本会比较高，有些方案会存在性能问题，而有些方案则更易于维护，而且性能也比较好。这里的关键影响因素就是代码质量。CSS、HTML、JavaScript这三种前端开发语言的特点是不同的，对代码质量的要求也不同，但它们之间又有着千丝万缕的联系。</p>
						</div>
			</div>
					
					<div style="clear: both;">&nbsp;</div>
				</div>
				<!-- end #content -->
				<!--工具栏---->
					<div id="sidebar">
					<div id="logo">
						<h1><a href="index.php"><font face="华文行楷">e佰web组</font></a></h1>
					</div>
					<div id="menu">
						<ul>
							<li><a href="index.php">web深情建议：</a></li>
							<li class="current_page_item"><a href="webfront.php">web前端介绍：</a></li>
							<li><a href="webafter.php">web后端介绍：</a></li>
							<li><a href="webfrontline.php">web前端学习：</a></li>
							<li><a href="webafterline.php">web后端学习：</a></li>
							<li><a href="webresource.php">web总体资料：</a></li>
							<li><a href="allplans.php">web整体计划：</a></li>
						</ul>
					</div>
					<div class="calendar">
						<?php 
						include("./tool/calendar.html");
						?>
					</div>
					<div class="ebaijishulianmeng">
						<span class="ebaijishulianmeng_title">特别关注：</span>
						<div class="ebaijishulianmeng_links">
							<div class="qq_links">
								<ul>
									<li style="type-list-style:none;">
										<h2><a href="#">QQ群</a></h2>	
									</li>
									<li>
										<h2><a href="http://jq.qq.com/?_wv=1027&k=ZNOcLF ">web-e佰技术联盟</a></h2>	
									</li>
								</ul>
							</div>
							<div class="weixin_links">
								<ul>
									<li style="type-list-style:none;">
										<h2><a href="#">微信号</a></h2>	
									</li>
									<li>
										<h2><a href="#">e佰web前端</a></h2>	
									</li>
									<li>
										<h2><a href="#">e佰web后端</a></h2>
									</li>
								</ul>
							</div>
						</div>
					</div>
					
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
				</div>
			</div>
	<!-- end #page-bgtop-->
		</div>
	<!--end #page-->
	</div>
<!--end #wrapper-->
</div>
<div id="footer">
	<p>Copyright (c) 2016 web.com. All rights reserved. Design by 河南理工大学e佰计算机协会web组.</p>
</div>
<!-- end #footer -->
</body>
</html>
