<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="Author" content="河南理工大学e佰web开发组">
<meta name="Keywords" content="河南理工大学e佰计算机协会、河南理工大学e佰web开发组、e佰web组，e佰web前端，e佰web后端">
<meta name="Description" content="河南理工大学e佰计算机协会、河南理工大学e佰web开发组、web组分为前后端、e佰web组，e佰web前端，e佰web后端、e佰web组总体资源">
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>e佰web组总体资源</title>

<link rel="stylesheet" type="text/css" href="./css/all.css"/>
<link href="./css/webresource.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/ebaiLogo.css"/>
<script type="text/javascript" src="./js/datetime.js"></script>
<script language="javascript">
function Time(){
	document.getElementById("localtime").innerText=new Date().toLocaleString();
  }
setInterval("Time()",1000);
</script>
</head>

<body>
	<?php 
   session_start();
   if(empty($_SESSION['password'])){
       header("Location:memberLogin.php?error=3");
   }
?>
<div class="music">
		<embed width="0px" height="0px" src="#" hidden="true"></embed>
</div>
<!--整体的外框，相当于body-->
<div id="wrapper">
	<div id="page">
		<div id="page-bgtop">
			
			<div id="page-bgbtm">
			
				<div id="content">
					<div class="top2">
						<!--时间-->
						<!--这个要通过js实现时间自动刷新的功能-->
						<div class="datetime">
							<span id="localtime" class="time"></span>
						</div>
						<!--格言-->
						<div class="motto">
							<span class="myMotto">平庸，只因只有想梦，却没有梦想。</span>
						</div>
					</div>
					<div class="amend">
						<span class="amend">
							<a href="admin/amendMemberInfor.php?done=memberUpdate" class="amendInfor">修改个人信息</a>
							<a href="?act=logout">安全退出</a>
							<?php 
							  
							     if(@$_GET['act']=='logout'){
							         session_destroy();
							         header("Location:index.html");
							     }
							?>
						</span>
					</div>
					<div style="clear: both;"></div>
				
					<!-- 下面是总体计划的内容 -->
                    <div class="allAims">
                    	<h1>web前后端资源汇总：</h1>
                    	<div id="con">
                    		<ul id="tags">
                    			  <li><a onClick="selectTag('tagContent0',this)" href="javascript:void(0)">前端资源汇总：</a></li>
                    			  <li class="selectTag"><a onClick="selectTag('tagContent1',this)" href="javascript:void(0)">后端资源汇总：</a></li>
                    		</ul>
                    		<div id="tagContent">
                    			<div class="tagContent selectTag" id="tagContent0">
                    				<div class="frontAim">
                    					<div class="aimTitle"><span>1.视频教程（个视频）：</span></div>
	                    			    	<ul>
	                    			  		    <li>第一阶段：<a href="https://yunpan.cn/cx7hqtjR4ssSz">html+css(22讲)  访问密码 1899</a></li>
	                    			    		<li>第二阶段：<a href=""></a></li>
	                    			    		<li>第三阶段：<a href=""></a></li>
	                    			    		<li>第四阶段：<a href=""></a></li>
	                    			    		<li>第五阶段：<a href=""></a></li>
	                    			    	</ul>
	                    			    <div class="aimTitle"><span>2.编辑器和工具：</span></div>
	                    					<ul>
	                    						<li>Editplus</li>
	                    						<li>HBuilder</li>
	                    						<li>SublimeText</li>	                    						
	                    						<li>Photoshop CC</li>
	                    						<li>Dreamwaver CS6</li>
	                    					</ul>
                    					
	                    				<div class="aimTitle"><span>3.各类手册及电子书：</span></div>
	                    					<ul>
	                    						<li>Html</li>
	                    						<li>CSS</li>
	                    						<li>JavaScript</li>
	                    						<li>jQuery</li>
	                    						<li>Html5+CSS3</li>
	                    					</ul>
	                    				<div class="aimTitle"><span>4.模板打包：</span></div>
                    					<ul>
                    						<li>div+css模板</li>
                    						<li></li>
                    						<li></li>
                    						<li>HBuilder</li>
                    						<li>Zend Studio</li>
                    					</ul>
                    					
	                    			</div>
	                    		</div>
                    			<div class="tagContent" id="tagContent1">
                    				<div class="afterAim">
                    					<div class="aimTitle"><span>1.视频教程（150个视频）：</span></div>
                    					<ul>
                    						<li>第一阶段：<a href="https://yunpan.cn/cx7hqtjR4ssSz">Html+CSS(22讲)  访问密码 1899</a></li>
                    						<li>第二阶段：<a href="https://yunpan.cn/cx7hp7Pqmvpt8">PHP入门：（13讲）访问密码 f5aa</a></li>
                    						<li>第三阶段：<a href="https://yunpan.cn/cx7CEIpU4Trxx">PHP基本语法：（25讲）访问密码 b043</a></li>
                    						<li>第四阶段：<a href="https://yunpan.cn/cx7CafDm2Vv3R">面向对象：（18讲）访问密码 bacb</a></li>
                    						<li>第五阶段：<a href="https://yunpan.cn/cx77gTbfHtCbF">HTTP协议与错误异常处理：（10讲）访问密码 a104</a></li>
                    						<li>第六阶段：<a href="https://yunpan.cn/cx77K3YmPTe23">MySQL数据库：（11讲）访问密码 5a1f</a></li>
                    						<li>第七阶段：<a href="https://yunpan.cn/cx77Qn8JVURIJ">雇员管理系统：（14讲）访问密码 4434</a></li>
                    						<li>第八阶段：<a href="https://yunpan.cn/cx776s2pvqk35">COOKIE和SESSION讲解： （8讲）访问密码 f750</a></li>
                    						<li>第九阶段：<a href="https://yunpan.cn/cx77rBN6SvtuX">文件上传与下载：（12讲）访问密码 0161</a></li>
                    						<li>第十阶段：<a href="https://yunpan.cn/cx77ekDpcTiPU">XML编程：（11讲）访问密码 7b30</a></li>
                    						<li>项目阶段：<a href="https://yunpan.cn/cx77Ur2vTW87H">网上支付平台：（5讲）访问密码 8955</a></li>
                    					</ul>
                    					<div class="aimTitle"><span>2.编辑器和工具：</span></div>
                    					<ul>
                    						<li>EditPlus &nbsp;&nbsp;&nbsp;&nbsp;：<a href="https://yunpan.cn/cYzWDFdGYfaGu">前期建议用Editplus(包含中英文多个版本）</a>访问密码 0194</li>
                    						<li>ZendStudio：<a href="https://yunpan.cn/cYzWNc8xmXRPf">后期建议用Zend Studio(包含3个最新版本) </a>访问密码 3ed5</li>
                    					</ul>
                    					
                    					<div class="aimTitle"><span>3.模板打包（2300套源码）：</span></div>
                    					<ul>
                    						<li>电子商务：<a href="https://yunpan.cn/cYEtrJeFG2BFx">关于电子商务的24套网站源码</a>访问密码 dd01</li>
                    						<li>交友会员：<a href="https://yunpan.cn/cYEtqkAjAKkFf">关于交友会员的22套网站源码</a>访问密码 86ed</li>
                    						<li>聊天留言：<a href="https://yunpan.cn/cYEtS8nYxIbHR">关于聊天留言的124套网站源码</a>访问密码 10c5</li>
                    						<li>论坛社区：<a href="https://yunpan.cn/cYEt6KT6XIPtg">关于论坛社区的274套网站源码</a>访问密码 a086</li>
                    						<li>企业政府：<a href="https://yunpan.cn/cYEtEp2ektAuI">关于企业政府的58套网站源码</a>访问密码 69c8</li>
                    						<li>人才房产：<a href="https://yunpan.cn/cYEtn9TLqnZQs">关于人才房产的17套网站源码</a>访问密码 b8e2</li>
                    						<li>搜索链接：<a href="https://yunpan.cn/cYEtGBJd2nVeM">关于搜索链接的85套网站源码</a>访问密码 08da</li>
                    						<li>图片动画：<a href="https://yunpan.cn/cYEt9HqbkAycx">关于图片动画的91套网站源码</a>访问密码 843d</li>
                    						<li>文件数据：<a href="https://yunpan.cn/cYEtUWVxBaXDx">关于文件数据的67套网站源码</a>访问密码 493e</li>
                    						<li>小偷采集：<a href="https://yunpan.cn/cYEtzVJjADCZp">关于小偷采集的66套网站源码</a>访问密码 3829</li>
                    						<li>信息办公：<a href="https://yunpan.cn/cYEt4euHx7SJK">关于信息办公的82套网站源码</a>访问密码 5d05</li>
                    						<li>学校班级：<a href="https://yunpan.cn/cYEtNS5Uukjdt">关于学校班级的111套网站源码</a>访问密码 8838</li>
                    						<li>整站程序：<a href="https://yunpan.cn/cYEtTdCFLjFjJ">关于整站程序的48套网站源码</a>访问密码 09db</li>
                    						<li>其他类别：<a href="https://yunpan.cn/cYEt2Is77V3ea">关于其他类别的199套网站源码</a>访问密码 f329</li>
                    					</ul>
                    				</div>
                    			</div>
                    		</div>
                    	</div>
                    </div>
						<script type=text/javascript>
							function selectTag(showContent,selfObj){
								// 给标签先清空然后附上指定的class选择器
								var tag = document.getElementById("tags").getElementsByTagName("li");
								var taglength = tag.length;
								for(var i=0; i<taglength; i++){
									tag[i].className = "";
								}
								//给所有的li加上selectTag 标签
								selfObj.parentNode.className = "selectTag";
								// 标签内容
								for(i=0; j=document.getElementById("tagContent"+i); i++){
										j.style.display = "none";
								}
								document.getElementById(showContent).style.display = "block";
							}
						</script>
					</div>
				<!--工具栏---->
				<div id="sidebar" style="float:left;">
					<div id="logo">
						<h1><a href="index.php"><font face="华文行楷">e佰web组</font></a></h1>
					</div>
					<div id="menu">
						<ul>
							<li><a href="index.php">web深情建议：</a></li>
							<li><a href="webfront.php">web前端介绍：</a></li>
							<li><a href="webafter.php">web后端介绍：</a></li>
							<li><a href="webfrontline.php">web前端学习：</a></li>
							<li><a href="webafterline.php">web后端学习：</a></li>
							<li class="current_page_item"><a href="webresource.php">web总体资料：</a></li>
							<li><a href="allplans.php">web整体计划：</a></li>
						</ul>
					</div>
					<div class="calendar">
						<?php 
						include("./tool/calendar.html");
						?>
					</div>
					<div class="ebaijishulianmeng">
						<span class="ebaijishulianmeng_title">特别关注：</span>
						<div class="ebaijishulianmeng_links">
							<div class="qq_links">
								<ul>
									<li style="type-list-style:none;">
										<h2><a href="#">QQ群</a></h2>	
									</li>
									<li>
										<h2><a href="http://jq.qq.com/?_wv=1027&k=ZNOcLF ">web-e佰技术联盟</a></h2>	
									</li>
								</ul>
							</div>
							<div class="weixin_links">
								<ul>
									<li style="type-list-style:none;">
										<h2><a href="#">微信号</a></h2>	
									</li>
									<li>
										<h2><a href="#">e佰web前端</a></h2>	
									</li>
									<li>
										<h2><a href="#">e佰web后端</a></h2>
									</li>
								</ul>
							</div>
						</div>
					</div>
					
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
				</div>
				<!-- end #content -->
				
			</div>
	<!-- end #page-bgtop-->
		</div>
		</div>
	<!--end #page-->
	</div>
<!--end #wrapper-->
</div>
<div id="footer">
	<p>Copyright (c) 2016 web.com. All rights reserved. Design by 河南理工大学e佰计算机协会web开发组.</p>
</div>
<!-- end #footer -->
</body>
</html>
