<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="Author" content="河南理工大学e佰web开发组">
<meta name="Keywords" content="河南理工大学e佰计算机协会、河南理工大学e佰web开发组、e佰web组，e佰web前端，e佰web后端">
<meta name="Description" content="河南理工大学e佰计算机协会、河南理工大学e佰web开发组、web组分为前后端、e佰web组，e佰web前端，e佰web后端">
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>e佰web组后端学习路线</title>
<link rel="stylesheet" type="text/css" href="css/all.css"/>
<link href="./css/webafterline.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/ebaiLogo.css"/>
<script type="text/javascript" src="./js/datetime.js"></script>
<script language="javascript">
function $(id){
	return getElementById(id);
}
</script>
</head>
<body>
	<?php 
   session_start();
   if(empty($_SESSION['password'])){
       header("Location:memberLogin.php?error=3");
   }
?>
<div class="music">

		<embed width="0px" height="0px" src="#" hidden="true"></embed>
	<!--
		http://play.baidu.com/?__m=mboxCtrl.playSong&__a=1362159&__o=song/s||playBtn&fr=-1||www.baidu.com#
    	作者：hpuwxy@foxmail.com
    	时间：2016-03-19
    	描述：
   		<object data="song/bgmusic.mp3" type="application/x-mplayer2" width="0" height="0"> 
		<param name="src" value="song/bgmusic.mp3"> 
		<param name="autostart" value="1"> 
		<param name="playcount" value="infinite"> 
	</object> 
    -->
	
</div>
<!--整体的外框，相当于body-->
<div id="wrapper">
	<div id="page">	
		<div id="page-bgtop">			
			<div id="page-bgbtm">	
				<div id="content">
					<div class="top2">
						<div class="datetime">
							<span id="localtime" class="time"></span>
						</div>
						<div class="motto">
							<span class="myMotto">平庸，只因只有想梦，却没有梦想。</span>
						</div>
					</div>
					<div class="amend">
						<span class="amend">
							<a href="admin/amendMemberInfor.php?done=memberUpdate" class="amendInfor">修改个人信息</a>
							<a href="?act=logout">安全退出</a>
							<?php 
							  
							     if(@$_GET['act']=='logout'){
							         session_start();
							         session_destroy();
							         header("Location:index.html");
							     }
							?>
						</span>
					</div>
					<div style="clear: both;"></div>	
					<div class="post">
						<h2 class="title">web后端学习路线：</h2>
						<div style="clear: both;">&nbsp;</div>
						<div class="entry">
							<?
							  header("Content-Type: text/html;charset=utf-8"); 
							
								function openFile($file_sub_dir,$filename,$i){  
								  //$file_sub_dir变量格式： 项目总文件夹/子文件夹
								  //读取文件，并把文件内容一次换行
								  $root=$_SERVER["DOCUMENT_ROOT"];
								  $file_path="$root/$file_sub_dir/$filename";
								  //$file_path="$root/webGroup/webafterline.txt";
								  //判断文件是否存在
								  if(!file_exists("$file_path")){
									  echo "文件不存在";
								  }else {
									  $fp=fopen($file_path,'rb');
									  $content_line=fgets($fp);
									  //开始读取文件
									  $content="";
									  while (!feof($fp)){
										  $content_line=fgets($fp);
										  $content.=$content_line."<br/>";
									  }
									   
									  //echo gettype("$content");//判断文件的类型是string，下面就是用explode（）函数拆分的问题了
									 $content_array=explode('@',$content);
									 echo $content_array[$i];
									  fclose($fp);
								  }   
							  }
						 ?> 
							<ul>
								<li id="a0"><?php openFile('webGroup/txt','webafterline01.txt',1);?></li>
								<li id="a1"><?php openFile('webGroup/txt','webafterline01.txt',2);?></li>
								<li id="a2"><?php openFile('webGroup/txt','webafterline01.txt',3);?></li>
								<li id="a3"><?php openFile('webGroup/txt','webafterline01.txt',4);?></li>
								<li id="a4"><?php openFile('webGroup/txt','webafterline01.txt',5);?></li>
								<li id="a5"><?php openFile('webGroup/txt','webafterline01.txt',6);?></li>
								<li id="a6"><?php openFile('webGroup/txt','webafterline01.txt',7);?></li>
								<li id="a7"><?php openFile('webGroup/txt','webafterline01.txt',8);?></li>
								<li id="a8"><?php openFile('webGroup/txt','webafterline01.txt',9);?></li>
							</ul>
						 <script language="javascript">
							  var contentArray=document.getEelementById("userId").value;
								 alert(contentArray.length);
								 alert(contentArray);
								 for(var j=0; j<contentArray.length;j++){
									  var nameId='a'+j;
									 window.alert(nameId);
										//document.getElementById(nameId).innerHTML=contentArray[j];   
								 }
						</script>
						
						</div>
					</div>
					<div style="clear: both;">&nbsp;</div>
				</div>
				<!-- end #content -->
				<!--工具栏---->
				<div id="sidebar">
					<div id="logo">
						<h1><a href="index.php"><font face="华文行楷">e佰web组</font></a></h1>
					</div>
					<div id="menu">
						<ul>
							<li><a href="index.php">web深情建议：</a></li>
							<li><a href="webfront.php">web前端介绍：</a></li>
							<li><a href="webafter.php">web后端介绍：</a></li>
							<li><a href="webfrontline.php">web前端学习：</a></li>
							<li class="current_page_item"><a href="webafterline.php">web后端学习：</a></li>
							<li><a href="webresource.php">web总体资料：</a></li>
							<li><a href="allplans.php">web整体计划：</a></li>
						</ul>
					</div>
					<div class="calendar">
						<?php 
						include("./tool/calendar.html");
						?>
					</div>
					<div class="ebaijishulianmeng">
						<span class="ebaijishulianmeng_title">特别关注：</span>
						<div class="ebaijishulianmeng_links">
							<div class="qq_links">
								<ul>
									<li style="type-list-style:none;">
										<h2><a href="#">QQ群</a></h2>	
									</li>
									<li>
										<h2><a href="http://jq.qq.com/?_wv=1027&k=ZNOcLF ">web-e佰技术联盟</a></h2>	
									</li>
								</ul>
							</div>
							<div class="weixin_links">
								<ul>
									<li style="type-list-style:none;">
										<h2><a href="#">微信号</a></h2>	
									</li>
									<li>
										<h2><a href="#">e佰web前端</a></h2>	
									</li>
									<li>
										<h2><a href="#">e佰web后端</a></h2>
									</li>
								</ul>
							</div>
						</div>
					</div>
					
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
				</div>
			</div>
	<!-- end #page-bgtop-->
		</div>
		</div>
	<!--end #page-->
	</div>
<!--end #wrapper-->
</div>
<div id="footer">
	<p>Copyright (c) 2016 web.com. All rights reserved. Design by 河南理工大学e佰计算机协会web组.</p>
</div>
<!-- end #footer -->
</body>   
</html>
